/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.Print to edit this template
 */
package Divers;

import javax.swing.*;
import java.text.*;

/**
 *
 * @author Israel
 */
public class Print {
    public static void imprimer(JTable jt, String titre){
        MessageFormat entete = new MessageFormat(titre);
        MessageFormat pied = new MessageFormat("Page (a, number, integer)");
        
        try {
            jt.print(JTable.PrintMode.FIT_WIDTH, entete, pied);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Erreur :\n" + e);
        }
    }
}
