
import gsfiConfig.Connect;
import gsfiGui.Accueil;
import gsfiGui.Auth;
import gsfiGui.SplashScreen;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author noudo
 * 
 * TU OUVRE Git Bash
 * Tu tape: Pour m'envoyer
 * cd ../Desktops
 * git add -A
 * git commit -m "Tu dit dans les crochers ce que tu as fait"
 * git push -u origin main
 * Puis c'est fini a chaque fois aue tu voudrais envoyer qlqch
 * Tu tape: Pour recevoir ce que j'ai fais
 * git pull
 * 
 */
public class Gestion_stock {

    /**
     * @param args the command line arguments
     */
    
//    public static void main(String[] args) {
//        // TODO code application logic here
//        new SplashScreen();
//        //Connect.se_connecter();
//    }

   
    
}
