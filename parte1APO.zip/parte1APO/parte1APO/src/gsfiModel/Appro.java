/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gsfiModel;

/**
 *
 * @author Israel
 */
public class Appro {
    private int ref, article, qte, vendeur;
    private String fournisseur;
    private String date;

    public Appro() {
    }

    public Appro(int ref, int article, int qte, int vendeur, String fournisseur, String date) {
        this.ref = ref;
        this.article = article;
        this.qte = qte;
        this.vendeur = vendeur;
        this.fournisseur = fournisseur;
        this.date = date;
    }

    public int getRef() {
        return ref;
    }

    public void setRef(int ref) {
        this.ref = ref;
    }

    public int getArticle() {
        return article;
    }

    public void setArticle(int article) {
        this.article = article;
    }

    public int getQte() {
        return qte;
    }

    public void setQte(int qte) {
        this.qte = qte;
    }

    public int getVendeur() {
        return vendeur;
    }

    public void setVendeur(int vendeur) {
        this.vendeur = vendeur;
    }

    public String getFournisseur() {
        return fournisseur;
    }

    public void setFournisseur(String fournisseur) {
        this.fournisseur = fournisseur;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

     
}
