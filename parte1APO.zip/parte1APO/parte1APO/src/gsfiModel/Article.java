/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gsfiModel;

import java.time.LocalDate;

/**
 *
 * @author noudo
 */
public class Article {
    private int code, quantite,limite;
    private String libelle;
    private double prix_unit;
    //LocalDate date_creation;
    private String date_creation;

    public Article() {
    }
    
    
//DROP TABLE if exists Article;
    public Article(int code, String libelle, int quantite, int limite, double prix_unit, String date_creation) {
        this.code = code;
        this.quantite = quantite;
        this.limite = limite;
        this.libelle = libelle;
        this.prix_unit = prix_unit;
        this.date_creation = date_creation;
    }
    
//    public Articles(int quantite, int limite, String libelle, double prix, LocalDate date_creation) {
//        this.quantite = quantite;
//        this.limite = limite;
//        this.libelle = libelle;
//        this.prix = prix;
//        this.date_creation = date_creation;
//    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    public int getLimite() {
        return limite;
    }

    public void setLimite(int limite) {
        this.limite = limite;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public double getPrix_unit() {
        return prix_unit;
    }

    public void setPrix(double prix) {
        this.prix_unit = prix;
    }
//
//    public LocalDate getDate_creation() {
//        return date_creation;
//    }
//
//    public void setDate_creation(LocalDate date_creation) {
//        this.date_creation = date_creation;
//    }
    
    
    
    //Firend plusieur parametr; sans un seul parametre
}
