/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gsfiModel;

/**
 *
 * @author Israel
 */
public class Vente {
    
    private int ref, qte, article, vendeur;
    private String client;
    private String date;

    public Vente() {
    }

    public Vente(int ref, int article,int qte, int vendeur, String client, String date) {
        this.ref = ref;
        this.article = article;
        this.vendeur = vendeur;
        this.client = client;
        this.date = date;
        this.qte = qte;
    }

    public int getRef() {
        return ref;
    }

    public void setRef(int ref) {
        this.ref = ref;
    }

    public int getArticle() {
        return article;
    }

    public void setArticle(int article) {
        this.article = article;
    }

    public int getVendeur() {
        return vendeur;
    }

    public void setVendeur(int vendeur) {
        this.vendeur = vendeur;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getQte() {
        return qte;
    }

    public void setQte(int qte) {
        this.qte = qte;
    }

    
    
}
