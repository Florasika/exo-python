/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gsfiServices;

import java.sql.Connection;
import java.sql.*;
import gsfiConfig.Connect;
import gsfiModel.Appro;
import gsfiModel.Article;
import gsfiModel.User;
import gsfiModel.Vente;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author noudo
 */

////////////////////////////////CRUD//////////////////////////////////////
public class ArticlesServices {
    
    public static boolean save (Article a) 
    {
        Connection con = Connect.se_connecter();
        boolean ajout = false;
        String request = "INSERT INTO article(libelle, quantite, limite, prix_unit, date_creation) VALUES (?,?,?,?,NOW())";
        
        try {
            PreparedStatement ps = con.prepareStatement(request);
            ps.setString(1, a.getLibelle());
            ps.setInt(2, a.getQuantite());
            ps.setInt(3, a.getLimite());
            ps.setDouble(4, a.getPrix_unit());
            //ps.setObject(5, a.getDate_creation());
            ps.execute();
            ajout = true;
            JOptionPane.showMessageDialog(null, "Le produit a bien ete enregistrer");
        } catch (SQLException ex) {
            Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return ajout;
    }
    
    public static boolean modifier (Article a ) {
        Connection con = Connect.se_connecter();
        boolean mod = false;
        String request = "update article set libelle =?, quantite = ?, prix_unit = ?, limite=? where code = ? ";
        
        try {
            PreparedStatement ps = con.prepareStatement(request);
            ps.setString(1, a.getLibelle());
            ps.setInt(2, a.getQuantite());
            ps.setDouble(3, a.getPrix_unit());
            ps.setInt(4, a.getLimite());
            ps.setInt(5, a.getCode());
            ps.execute();
            mod = true;
        } catch (SQLException ex) {
            Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return true;
    }
    
    public static boolean supprimer (Article a) {
        Connection con = Connect.se_connecter();
        boolean sup = false;
        String request = "delete from article where code = ?";
        try {
            PreparedStatement ps = con.prepareStatement(request);
            ps.setInt(1, a.getCode());
            ps.execute();
            sup = true;
        } catch (SQLException ex) {
            Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sup;
    }
    
    public static boolean vendre (Article a) {
        Connection con = Connect.se_connecter();
        boolean vent = false;
        String request = "update article set quantite = ? where code = ?";
        try {
            PreparedStatement ps = con.prepareStatement(request);
            ps.setInt(1, a.getQuantite());
            ps.setInt(2, a.getCode());
            ps.execute();
            vent = true;
        } catch (SQLException ex) {
            Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
        }
        return vent;
    }
    
    public static boolean approv (Article a) {
        Connection con = Connect.se_connecter();
        boolean ap = false;
        String request = "update article set quantite = ? where code = ?";
        try {
            PreparedStatement ps = con.prepareStatement(request);
            ps.setInt(1, a.getQuantite());
            ps.setInt(2, a.getCode());
            ps.execute();
            ap = true;
        } catch (SQLException ex) {
            Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ap;
    }
    
    public static boolean ajoutVente(Article a, User u, String client) {
        Connection con = Connect.se_connecter();
        boolean av =  false;
        String request = "INSERT INTO `vente`(`article`, `vendeur`, `qte`, `client`, `dateV`) VALUES (?,?,?,?,NOW())";
        
        try {
            PreparedStatement ps = con.prepareStatement(request);
            ps.setInt(1, a.getCode());            
            ps.setInt(2, u.getId());
            ps.setInt(3, a.getQuantite());
            ps.setString(4, client);
            ps.execute();
            av = true;
        } catch (SQLException ex) {
            Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
        }
        return av;
    }
    
    public static boolean approvision(Article a, User u, String client) {
        Connection con = Connect.se_connecter();
        boolean ap =  false;
        String request = "INSERT INTO `appro`(`article`, `utilisateur`, `qte`, `fourniseur`, `dateV`) VALUES (?,?,?,?,NOW())";
        
        try {
            PreparedStatement ps = con.prepareStatement(request);
            ps.setInt(1, a.getCode());            
            ps.setInt(2, u.getId());
            ps.setInt(3, a.getQuantite());
            ps.setString(4, client);
            ps.execute();
            ap = true;
        } catch (SQLException ex) {
            Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ap;
    }


///////////////////////////////////Listes pour model /////////////////////////////////    
    public static List<Article> listArticles() throws SQLException 
    {
        Connection con = (Connection)Connect.se_connecter();
        String request = "select * from article";
        ResultSet rs;
        List<Article> list = new ArrayList<>();
        Statement st = con.createStatement();
        rs = st.executeQuery(request);
        while(rs.next())
        {
            Article a = new Article();
            a.setCode(rs.getInt("code"));
            a.setQuantite(rs.getInt("quantite"));
            a.setLimite(rs.getInt("limite"));
            a.setPrix(rs.getDouble("prix_unit"));
            //a.setDate_creation(rs.getDate("date_creation"));
            a.setLibelle(rs.getString("libelle"));
            list.add(a);
        }
        return list;
        
    }
    
    public static List<Vente> listArticleVendu() throws SQLException 
    {
        Connection con  = Connect.se_connecter();
        String request = "select * from vente";
        ResultSet rs;
        List<Vente> list = new ArrayList<>();
        Statement st = con.createStatement();
        rs = st.executeQuery(request);
        while(rs.next()){
            Vente v = new Vente();
            v.setRef(rs.getInt("ref"));
            v.setArticle(rs.getInt("article"));
            v.setClient(rs.getString("client"));
            v.setDate(rs.getString("dateV"));
            list.add(v);
        }
        //rs = st.executeQuery(request);
        
        return list;
    }
    
    public static List<Appro> listArticleAppro() throws SQLException 
    {
        Connection con  = Connect.se_connecter();
        String request = "select * from appro";
        ResultSet rs;
        List<Appro> list = new ArrayList<>();
        Statement st = con.createStatement();
        rs = st.executeQuery(request);
        while(rs.next()){
            Appro a = new Appro();
            a.setRef(rs.getInt("ref"));
            a.setArticle(rs.getInt("article"));
            a.setFournisseur(rs.getString("fourniseur"));
            a.setDate(rs.getString("dateV"));
            list.add(a);
        }
        //rs = st.executeQuery(request);
        
        return list;
    }
    
    public static List<Article> listArticleRecherche(String libelle) throws SQLException {
        Connection con = Connect.se_connecter();
        String request = "SELECT * FROM article WHERE libelle LIKE ?";
        
        PreparedStatement ps = con.prepareStatement(request);
        ps.setString(1, "%"+libelle+"%");
        ResultSet rs = ps.executeQuery();
        List<Article> list = new ArrayList<>();
        while(rs.next()){
            Article a = new Article();
            a.setCode(rs.getInt("code"));
            a.setQuantite(rs.getInt("quantite"));
            a.setLimite(rs.getInt("limite"));
            a.setPrix(rs.getDouble("prix_unit"));
            //a.setDate_creation(rs.getDate("date_creation"));
            a.setLibelle(rs.getString("libelle"));
            list.add(a);
        }
        return list;
    }
    
    public static int ndArticleStock () 
    {
        Connection con = Connect.se_connecter();
        String request = "select count(*) as nb from article where limite < quantite";
        int nb = 3;
        ResultSet rs;
        try {
            Statement st = con.createStatement();
            rs = st.executeQuery(request);
            while(rs.next()) {
                nb = (int)rs.getInt("nb");
            }
            //nb = (int)rs.next().getInt(1);
        } catch (SQLException ex) {
            Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return nb;
    }
    
    
//////////////////////////////DEfault Table Model ///////////////////////////////////
    public static DefaultTableModel maTableModelAcceuil()
    {
        DefaultTableModel model = new DefaultTableModel();
        String[] entete = {"STATUT", "ID","LIBELLE", "QUANTITE","PRIX", " ", " ", " "};
        model.setColumnIdentifiers(entete);
        
        try {    
            JButton btn = new JButton();
            List<Article> list = listArticles();
            for(Article a :  list)
            {
                Object[] donnees = {a.getLimite(),
                                    a.getCode()+"",
                                    a.getLibelle()+"",
                                    a.getQuantite(),
                                    a.getPrix_unit()+"",
                                    btn, //Case destiner a contenir le button 
                                    btn,//Case destiner a contenir le button
                                    btn,//Case destiner a contenir le button
                };
                                    //a.getDate_creation().toString(),
                                    
                model.addRow(donnees);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
        }
        return model;
    }
    
    public static DefaultTableModel tableModelRecherche(String libelle){
        DefaultTableModel model = new DefaultTableModel();
        String[] entete = {"STATUT", "ID","LIBELLE", "QUANTITE","PRIX", " ", " ", " "};
        model.setColumnIdentifiers(entete);
        
        try {    
            JButton btn = new JButton();
            List<Article> list = listArticleRecherche(libelle);
            for(Article a :  list)
            {
                Object[] donnees = {a.getLimite(),
                                    a.getCode()+"",
                                    a.getLibelle()+"",
                                    a.getQuantite(),
                                    a.getPrix_unit()+"",
                                    btn, //Case destiner a contenir le button 
                                    btn,//Case destiner a contenir le button
                                    btn,//Case destiner a contenir le button
                };
                                    //a.getDate_creation().toString(),
                                    
                model.addRow(donnees);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
        }
        return model;
        /*
        DefaultTableModel model = new DefaultTableModel();
        
        String[] entete = {"STATUT", "ID", "LIBELLE", "QUANTITE", "PRIX", "", "", ""};
        model.setColumnIdentifiers(entete);
        
        String query = "SELECT * FROM article WHERE libelle LIKE ?";
    try {
        
        Connection con = Connect.se_connecter();
        PreparedStatement ps = null;
        ResultSet resultSet = null;
        ps = con.prepareStatement(query);
        ps.setString(1, "%" + libelle + "%");
        
        resultSet = ps.executeQuery();
        
        
        while (resultSet.next()) {
            int limite = resultSet.getInt("limite");
            int code = resultSet.getInt("code");
            String libelleResult = resultSet.getString("libelle");
            int quantite = resultSet.getInt("quantite");
            double prix = resultSet.getDouble("prix_unit");
            // Date date_creation = resultSet.getDate("date_creation"); // Supposons que la colonne "date_creation" n'est pas utilisée
            
            Object[] obj = {limite, code, libelleResult, quantite, prix, new JButton(), new JButton()};
            model.addRow(obj);
        }
        
    } catch (SQLException ex) {
        Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
    }
    return model; */
  }
    
    public static DefaultTableModel maTableModelStatVendu() {
        DefaultTableModel model = new DefaultTableModel();
        String [] entete = {"Reference","Article", "Vendeur", "Client", "Date"};
        model.setColumnIdentifiers(entete);
        
        List<Vente> list;
        try {
            list = listArticleVendu();
            for(Vente v : list) {
            //int qte = (int) (a.getQuantite() * a.getPrix_unit());
            String[] donnees = {
                                v.getRef()+"",
                                v.getArticle()+"",
                                v.getVendeur()+"",
                                v.getClient()+"",
                                v.getDate()+""
            };
            model.addRow(donnees);
        }
        } catch (SQLException ex) {
            Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return model;
    }
    
    public static DefaultTableModel maTableModelStatAppro() {
        DefaultTableModel model = new DefaultTableModel();
        String [] entete = {"Reference","Article", "Vendeur", "Fournisseur", "Date"};
        model.setColumnIdentifiers(entete);
        
        List<Appro> list;
        try {
            list = listArticleAppro();
            for(Appro v : list) {
            //int qte = (int) (a.getQuantite() * a.getPrix_unit());
            String[] donnees = {
                                v.getRef()+"",
                                v.getArticle()+"",
                                v.getVendeur()+"",
                                v.getFournisseur()+"",
                                v.getDate()+""
            };
            model.addRow(donnees);
        }
        } catch (SQLException ex) {
            Logger.getLogger(ArticlesServices.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return model;
    }
    
}
