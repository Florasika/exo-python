/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gsfiBtnEditor;

import gsfiGui.Modification;
import gsfiGui.Vente_produit;
import java.awt.Button;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractCellEditor;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import gsfiModel.*;

/**
 *
 * @author Israel
 */
public class BtnEditor_1  extends AbstractCellEditor implements TableCellEditor {
    
    private String label;    
    private JButton button;


    public BtnEditor_1() {
        button = new JButton();
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Modification().setVisible(true);
            }
            
        });
    }
    
    public BtnEditor_1(Article a) {
        button = new JButton();
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Modification(a).setVisible(true);
            }
            
        });
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        label = "Modifier";
        button.setText(label);
        return button;
    }

    @Override
    public Object getCellEditorValue() {
        return null;
    }
    
    
    
    
    
}
