/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gsfiBtnEditor;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *table.setDefaultRenderer(Sexe.class, new SexeCellRenderer());
 *table.getColumnModel().getColumn(4).setCellRenderer(new NoteCellRenderer());
 * @author Israel
 */
public class SeuilCellRenderer extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        Component com = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column); 
        int realindex = table.convertColumnIndexToView(3); // on compare avec la colonne 8
	Integer val1 = (Integer)table.getValueAt(row,realindex); 
	Integer val2 = (Integer)value;
	if(val1 <= val2 ) 
	  com.setBackground(Color.RED);
        else
	  com.setBackground(Color.GREEN);
        
        return this;
    }
    
    
    
}
