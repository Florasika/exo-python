 

/*CREATION DE LA BASE DE DONNEES*/

CREATE DATABASE stock;


DROP TABLE if exists articles;

/*CREATION DE LA TABLE ARTICLES*/

CREATE TABLE articles(
    code integer PRIMARY KEY AUTO_INCREMENT,
    quantite integer,
    limite integer,
    prix_unit double,
    date_creation date);

DROP TABLE if exists utilisateur;


/*CREATION DE LA TABLE UTILISATEUR*/


CREATE TABLE utilisateur(
    id integer PRIMARY KEY AUTO_INCREMENT,
    nom varchar(50),
    pass varchar(50));

DROP TABLE if exists login_table;

CREATE TABLE login_table (
    login varchar(50) PRIMARY KEY;
    password varchar(50);
    nom varchar(50);
    prenom varchar(50);
    type varchar(50)
);

DROP TABLE if exists vente;

CREATE TABLE vente (
    ref int PRIMARY KEY AUTO_INCREMENT,
    article int,
    vendeur int,
    qte int, 
    client varchar(30),
    dateV timestamp
);

DROP TABLE if exists appro;

CREATE TABLE appro (
    ref int PRIMARY KEY AUTO_INCREMENT;
    article int,
    utilisateur int,
    qte int,
    fourniseur varchar(30),
    dateV timestamp
);