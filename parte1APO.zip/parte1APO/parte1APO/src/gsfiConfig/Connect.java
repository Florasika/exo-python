/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gsfiConfig;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;



/**
 *
 * @author israel
 */
public class Connect {
    
    public static Connection se_connecter(){
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Connect.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //Renseignement des,identifiants de connexion
        String urli = "jdbc:mysql://localhost/stock?characterEncoding=latin1";
        String username = "root";
        String pass = "root";
        
        Connection con;
        
        try {
            con = DriverManager.getConnection(urli, username,pass);
            //JOptionPane.showMessageDialog(null, "On se vesse");
            return con;
        } catch (SQLException ex) {
            Logger.getLogger(Connect.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "C'est quoi tu fais?");
            return null;
        }
        
        
        
        
    }
}
